"""Tests for the datavents module."""
