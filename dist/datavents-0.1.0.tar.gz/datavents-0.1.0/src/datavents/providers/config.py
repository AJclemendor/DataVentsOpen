from enum import Enum
class Config(Enum):
    LIVE = "live"
    PAPER = "paper"
    NOAUTH = "noauth"